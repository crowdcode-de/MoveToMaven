package de.extra.client.plugins.dataPlugin;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import de.extra.client.core.ExtraClient;
import de.extra.client.core.model.VersanddatenBean;
import de.extra.client.core.plugin.IDataPlugin;
import de.extra.client.plugins.dataPlugin.interfaces.IDataPluginController;

public class DataPlugin implements IDataPlugin {
	
	/**
	 * Pfad und Dateiname in der die SpringConfig.xml liegt
	 */

	private static String SPRING_XML_FILE_PATH = "ConfigDataPlugin.xml";
	
	/**
	 * Dateipfad der log4jProperties 
	 */

	private static final String LOG_4_J_FILE = "log4j.properties";
	
	
	private static Logger logger = Logger.getLogger(ExtraClient.class);

	public List<VersanddatenBean> getVersandDaten() {
		
		
		PropertyConfigurator.configureAndWatch(LOG_4_J_FILE);
		logger.info("Start des Versands");

		// Spring Beans laden.
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				SPRING_XML_FILE_PATH);

		IDataPluginController controller = (IDataPluginController) applicationContext.getBean("dataPluginController");
		
		List versanddatenListe = new ArrayList();
		
		versanddatenListe = controller.processData();
		
		logger.info("Verarbeitung der Versanddaten abgeschlossen");
		
		return versanddatenListe;
	}


	

}
