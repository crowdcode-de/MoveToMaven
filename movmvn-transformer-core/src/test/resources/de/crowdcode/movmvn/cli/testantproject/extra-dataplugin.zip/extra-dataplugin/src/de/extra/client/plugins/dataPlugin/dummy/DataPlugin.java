package de.extra.client.plugins.dataPlugin.dummy;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.extra.client.core.model.CompressionPluginBean;
import de.extra.client.core.model.DataSourcePluginBean;
import de.extra.client.core.model.EncryptionPluginBean;
import de.extra.client.core.model.PlugindatenBean;
import de.extra.client.core.model.VersanddatenBean;
import de.extra.client.core.plugin.IDataPlugin;

public class DataPlugin implements IDataPlugin {

	public List<VersanddatenBean> getVersandDaten() {

		List<VersanddatenBean> versanddatenList = new ArrayList<VersanddatenBean>();

		versanddatenList.add(loadVersanddaten());

		return versanddatenList;
	}

	/**
	 * Dummy-Klasse mit statischen Werten
	 * 
	 * @return Versanddatenbean
	 */
	private VersanddatenBean loadVersanddaten() {

		VersanddatenBean vb = new VersanddatenBean();
		CompressionPluginBean compressionPlugin = new CompressionPluginBean();
		EncryptionPluginBean encryptionPlugin = new EncryptionPluginBean();
		DataSourcePluginBean dataSourcePlugin = new DataSourcePluginBean();

		String nutzdaten = "Testdaten";

		// Nutzdaten setzen

		vb.setNutzdaten(nutzdaten.getBytes());

		// Compression-Infos setzen

		compressionPlugin.setOrder(1);
		compressionPlugin
				.setCompAlgoId("http://www.extra-standard.de/transforms/compression/NONE");
		compressionPlugin.setCompAlgoVers("1.0");
		compressionPlugin.setCompAlgoName("KKS");

		compressionPlugin.setCompSpecUrl("http://www.datentausch.de");
		compressionPlugin.setCompSpecName("KKS");
		compressionPlugin.setCompSpecVers("1.0");

		compressionPlugin.setCompInput(200);
		compressionPlugin.setCompOutput(100);

		// Encryption-Infos setzen

		encryptionPlugin.setOrder(2);
		encryptionPlugin
				.setEncAlgoId("http://www.extra-standard.de/transforms/encryption/PKCS7");
		encryptionPlugin.setEncAlgoVers("1.3");
		encryptionPlugin.setEncAlgoName("KKS");

		encryptionPlugin.setEncSpecUrl("http://www.datentausch.de");
		encryptionPlugin.setEncSpecName("KKS");
		encryptionPlugin.setEncSpecVers("1.5.1");

		encryptionPlugin.setEncInput(100);
		encryptionPlugin.setEncOutput(200);

		// DataSource-Infos setzen

		dataSourcePlugin.setDsType("http://extra-standard.de/container/FILE");
		dataSourcePlugin.setDsName("EDUA0000003");

		Date datum = new Date();
		datum.setMonth(0);
		datum.setDate(12);
		datum.setYear(110);
		dataSourcePlugin.setDsCreated(datum);
		dataSourcePlugin.setDsEncoding("I8");

		List<PlugindatenBean> pluginList = new ArrayList<PlugindatenBean>();

		pluginList.add(compressionPlugin);
		pluginList.add(encryptionPlugin);
		pluginList.add(dataSourcePlugin);

		vb.setPlugins(pluginList);

		return vb;

	}

}
