package de.extra.client.plugins.dataPlugin.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import de.extra.client.core.model.VersanddatenBean;
import de.extra.client.plugins.dataPlugin.auftragssatz.AuftragssatzType;
import de.extra.client.plugins.dataPlugin.helper.DataPluginHelper;
import de.extra.client.plugins.dataPlugin.interfaces.IDataPluginController;

public class DataPluginController implements IDataPluginController {

	private final DataPluginHelper dataPluginHelper;

	public DataPluginController(final DataPluginHelper dataPluginHelper) {
		super();
		this.dataPluginHelper = dataPluginHelper;
	}

	/**
	 * Verarbeitungs-Controller f�r das DataPlugin
	 */
	
	public List<VersanddatenBean> processData() {
		List<VersanddatenBean> versanddatenBeanList = new ArrayList<VersanddatenBean>();

		List nutzfileList = new ArrayList<String>();

		//Ermitteln der Nutzdaten
		
		nutzfileList = dataPluginHelper.getNutzfiles();

		//Bef�llen der Versanddaten-Liste
		
		for (Iterator iter = nutzfileList.iterator(); iter.hasNext();) {
			String filename = (String) iter.next();

			VersanddatenBean versanddatenBean = new VersanddatenBean();

			versanddatenBean.setNutzdaten(dataPluginHelper
					.getNutzdaten(filename));
			
			AuftragssatzType auftragssatz = new AuftragssatzType();
			
			String auftragssatzName = filename + ".auf";
			
			auftragssatz = dataPluginHelper.unmarshalAuftragssatz(auftragssatzName);
			
			//Setzen der RequestId
			
			versanddatenBean.setRequestId(auftragssatz.getRequestId());
			
			versanddatenBean = dataPluginHelper.fuelleVersandatenBean(versanddatenBean, auftragssatz);
			
			versanddatenBeanList.add(versanddatenBean);

		}

		return versanddatenBeanList;
	}

}
