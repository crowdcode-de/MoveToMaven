package de.extra.client.plugins.dataPlugin.interfaces;

import java.util.List;

import de.extra.client.core.model.VersanddatenBean;

public interface IDataPluginController {
	
	public List<VersanddatenBean> processData();

}
